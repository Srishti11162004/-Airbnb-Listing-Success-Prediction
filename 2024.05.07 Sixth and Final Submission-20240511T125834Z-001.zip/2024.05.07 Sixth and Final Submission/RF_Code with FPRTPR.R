#RF model
library(ranger)
library(xgboost)
rf.mod <- ranger(x = trained_fit, y = trained_y,
                 mtry=22, num.trees=500,
                 importance="impurity",
                 probability = TRUE)

rf_preds <- predict(rf.mod, data=valid_fit)$predictions
rf_preds <- rf_preds[,2]
rf_classifications <- ifelse(rf_preds>0.43, 1, 0)
confusion_matrix <- table(rf_classifications, valid_y)
print(confusion_matrix)
TP <- confusion_matrix[2, 2]  # True Positives
FP <- confusion_matrix[2, 1]  # False Positives
FN <- confusion_matrix[1, 2]  # False Negatives
TN <- confusion_matrix[1, 1]  # True Negatives

# Calculate True Positive Rate (TPR) or Sensitivity or Recall
TPR <- TP / (TP + FN)

# Calculate False Positive Rate (FPR)
FPR <- FP / (FP + TN)